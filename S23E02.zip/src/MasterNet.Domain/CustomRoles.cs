namespace MasterNet.Domain;

public static class CustomRoles
{

    public const string ADMIN = nameof(ADMIN);
    public const string CLIENT = nameof(CLIENT);


}