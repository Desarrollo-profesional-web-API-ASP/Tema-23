namespace MasterNet.Domain;

public static class CustomClaims
{
    public const string POLICIES = nameof(POLICIES);
}